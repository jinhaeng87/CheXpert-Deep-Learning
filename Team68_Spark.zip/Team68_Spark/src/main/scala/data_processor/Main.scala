package data_processor

//import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.{DataFrame, SQLContext, SparkSession, Row}
//import org.apache.log4j.{Level, Logger}
import setup.{SparkSetup }
import scala.util.control.Breaks._
//import org.apache.hadoop.conf.Configuration
//import org.apache.hadoop.fs.FileSystem
//import org.apache.hadoop.fs.Path
//import java.io.PrintWriter

//SparkSession
//import org.apache.spark.sql.SQLContext

/**
 *
 *  AUTHOR:
 *  Jin Haeng Lee <jlee3693@gatech.edu>, Ryan Gust <rgust3@gatech.edu>, Tiga Choi <tchoi43@gatech.edu>
 *
 *  PURPOSE:
 *  1. To consolidate training and validatiion CHeXpert CSV files
 *  2. To assign unique image_file_id for each record
 *  3. To output sample files based upon specified paramaters (below)
 *
 */


object Main extends App{
  /**
   * Parameters need to be specified by users
   */
  //File path for CheXpoert raw data
  val file_in_train = "data/input/chexpert/train.csv"                         //File path for CheXPert training data
  val file_in_valid = "data/input/chexpert/valid.csv"                         //File path for CheXPert validation data

  //File path for consolidated and sample data
  val file_out_consolid = "data/output/chexpert/Team68_CheXpert_Full"        //Directory should not exist before processing
  val file_out_sample = "data/output/chexpert/Team68_Sample_001"                    //Directory should not exist before processing

  //Output type      1: for generating consolidated file   2: for generating sample file   3: for both
  val output_type = 3

  //Parameters for training and test dataset sizes and run attempts
  val num_sample = 120000           //Sampled based upon number of patient studies, NOT number of images
  val size_test = 0.30              //Test size portion
  val max_try = 100                 //Maximum Number of attempts
  val seed_value = 1000             //Base seed

  //Parameters for validating projection representiveness
  val min_proj_num = 50                           //Minimum number of images per Projection
  val min_diag_num = 50                           //Minimum number of images per Diagnosis
  val min_proj_perc = Array(0.5, 0.1, 0.1)        //Minimum population percentage  Order: AP, PA, LL

  //Parameters for validating diagnosis representation
  val min_diag_perc_thres = 0.7                  //Minimum percentage from base representiveness for each diagnosis (below)
  val chex_diag_perc = Array(0.092372222, 0.050111111, 0.127788888, 0.514827777, 0.038088888, 0.271694444, 0.070722222, 0.025422222, 0.162961111, 0.096183333, 0.420533333, 0.013561111, 0.040388888, 0.587950000)
  //Order: No_Finding, Enlarged_Cardiomediastinum, Cardiomegaly, Lung_Opacity, Lung_Lesion, Edema, Consolidation
  //       Pneumonia, Atelectasis, Pneumothorax, Pleural_Effusion, Pleural_Other, Fracture, Support_Devices

  /**
   * End of Parameter specification
   */

  //Begin program code
  //Set up basic configuration for Scala and Spark
  val spark = SparkSetup.spark
  import spark.implicits._
  val sqlContext = spark.sqlContext
  //val spases: SparkSession = SparkSession.builder.master("local").appName("Team68_Scala").getOrCreate()

  //Calculate minimum diagnosis percentage
  val min_diag_perc = chex_diag_perc.map((_ * min_diag_perc_thres))

  //Main program code: Generate master file or sample file
  if (output_type == 1 | output_type == 3) {Generate_Master_File}
  if (output_type == 2 | output_type == 3) {Generate_Sample}

  //Function to import CheXpert datasets
  def ImportCSV_Table(spark:SparkSession, filepath: String, delimit: String): DataFrame = {
    val df = spark.read.option("header", "true").
      option("delimiter", delimit).
      csv(filepath)
    return df
  }

  //Function to pre-process the master data file for subsequent processing
  def Generate_Master_File {
    //Import CheXpert training and validation datasets
    val df_train = ImportCSV_Table(spark, filepath = file_in_train, delimit = ",")
    val df_valid = ImportCSV_Table(spark, filepath = file_in_valid, delimit = ",")

    //Pre-process and Parse fields for the two datasets
    df_train.createOrReplaceTempView("tbl_train")
    df_valid.createOrReplaceTempView("tbl_valid")

    val df_train2 = sqlContext.sql("SELECT 1 as Dataset_ID, substring(Path, instr(Path, 'patient')+7, 5) as patient_id_text, substring(upper(Sex), 1, 1) as gender, int(Age) as age_num, case when upper(`Frontal/Lateral`) = 'LATERAL' then 'LL' when upper(`Frontal/Lateral`) = 'FRONTAL' and upper(`AP/PA`) in ('AP', 'PA') then `AP/PA` else 'XX' end as ap_pa_ll, Path as File_Path, string(`No Finding`) as No_Finding, string(`Enlarged Cardiomediastinum`) as Enlarged_Cardiomediastinum, string(Cardiomegaly) as Cardiomegaly, string(`Lung Opacity`) as Lung_Opacity, string(`Lung Lesion`) as Lung_Lesion, string(Edema) as Edema, string(Consolidation) as Consolidation, string(Pneumonia) as Pneumonia, string(Atelectasis) as Atelectasis, string(Pneumothorax) as Pneumothorax, string(`Pleural Effusion`) as Pleural_Effusion, string(`Pleural Other`) as Pleural_Other, string(Fracture) as Fracture, string(`Support Devices`) as Support_Devices from tbl_train ")
    val df_valid2 = sqlContext.sql("SELECT 2 as Dataset_ID, substring(Path, instr(Path, 'patient')+7, 5) as patient_id_text, substring(upper(Sex), 1, 1) as gender, int(Age) as age_num, case when upper(`Frontal/Lateral`) = 'LATERAL' then 'LL' when upper(`Frontal/Lateral`) = 'FRONTAL' and upper(`AP/PA`) in ('AP', 'PA') then `AP/PA` else 'XX' end as ap_pa_ll, Path as File_Path, string(`No Finding`) as No_Finding, string(`Enlarged Cardiomediastinum`) as Enlarged_Cardiomediastinum, string(Cardiomegaly) as Cardiomegaly, string(`Lung Opacity`) as Lung_Opacity, string(`Lung Lesion`) as Lung_Lesion, string(Edema) as Edema, string(Consolidation) as Consolidation, string(Pneumonia) as Pneumonia, string(Atelectasis) as Atelectasis, string(Pneumothorax) as Pneumothorax, string(`Pleural Effusion`) as Pleural_Effusion, string(`Pleural Other`) as Pleural_Other, string(Fracture) as Fracture, string(`Support Devices`) as Support_Devices from tbl_valid ")

    df_train2.createOrReplaceTempView("tbl_train2")
    df_valid2.createOrReplaceTempView("tbl_valid2")

    val df_train3 = sqlContext.sql("SELECT int(Dataset_ID) as Dataset_ID, case when substring(patient_id_text, 1, 4)='0000' then int(substring(patient_id_text,5,1)) when substring(patient_id_text, 1, 3)='000' then int(substring(patient_id_text,4,2)) when substring(patient_id_text, 1, 2)='00' then int(substring(patient_id_text,3,3)) when substring(patient_id_text, 1, 1)='0' then int(substring(patient_id_text,2,4)) else int(patient_id_text) end as patient_id, int(replace(substring(File_Path, instr(File_Path, 'study')+5, 2), '/', '')) as study, int(substring(File_Path, instr(File_Path, 'view')+4, 1)) as view_num, gender, age_num, ap_pa_ll, File_Path as Path, No_Finding, Enlarged_Cardiomediastinum, Cardiomegaly, Lung_Opacity, Lung_Lesion, Edema, Consolidation, Pneumonia, Atelectasis, Pneumothorax, Pleural_Effusion, Pleural_Other, Fracture, Support_Devices from tbl_train2 where ap_pa_ll <> 'XX' and age_num >= 20 order by 1, 2, 3, 4, 5") // and (Enlarged_Cardiomediastinum is not null or Cardiomegaly is not null or Lung_Opacity is not null or Lung_Lesion is not null or Edema is not null or Consolidation is not null or Pneumonia is not null or Atelectasis is not null or Pneumothorax is not null or Pleural_Effusion is not null or Pleural_Other is not null or Fracture is not null or Support_Devices is not null or No_Finding is not null)")
    val df_valid3 = sqlContext.sql("SELECT int(Dataset_ID) as Dataset_ID, case when substring(patient_id_text, 1, 4)='0000' then int(substring(patient_id_text,5,1)) when substring(patient_id_text, 1, 3)='000' then int(substring(patient_id_text,4,2)) when substring(patient_id_text, 1, 2)='00' then int(substring(patient_id_text,3,3)) when substring(patient_id_text, 1, 1)='0' then int(substring(patient_id_text,2,4)) else int(patient_id_text) end as patient_id, int(replace(substring(File_Path, instr(File_Path, 'study')+5, 2), '/', '')) as study, int(substring(File_Path, instr(File_Path, 'view')+4, 1)) as view_num, gender, age_num, ap_pa_ll, File_Path as Path, No_Finding, Enlarged_Cardiomediastinum, Cardiomegaly, Lung_Opacity, Lung_Lesion, Edema, Consolidation, Pneumonia, Atelectasis, Pneumothorax, Pleural_Effusion, Pleural_Other, Fracture, Support_Devices from tbl_valid2 order by 1, 2, 3, 4, 5")

    //Combine the two datasets and generate a Unique one-based CheX_Image_ID
    val df_comb = df_train3.union(df_valid3)
    val rdd_comb = df_comb.rdd.zipWithIndex()

    //Merge CheX_Image_ID with combined dataset based upon data unique key (patient_ID, study and view)
    val df_seq = rdd_comb.map(row => (row._2 + 1, row._1.getInt(0), row._1.getInt(1), row._1.getInt(2), row._1.getInt(3))).toDF
    //df_seq.show(10)
    val df_comb_final = df_comb.join(df_seq, df_comb("Dataset_ID") === df_seq("_2") && df_comb("patient_id") === df_seq("_3") && df_comb("study") === df_seq("_4") && df_comb("view_num") === df_seq("_5")).select($"Dataset_ID", $"_1" as "CheX_Image_ID", $"patient_id", $"gender", $"study", $"view_num", $"age_num", $"ap_pa_ll", $"Path", $"No_Finding", $"Enlarged_Cardiomediastinum", $"Cardiomegaly", $"Lung_Opacity", $"Lung_Lesion", $"Edema", $"Consolidation", $"Pneumonia", $"Atelectasis", $"Pneumothorax", $"Pleural_Effusion", $"Pleural_Other", $"Fracture", $"Support_Devices")
    //df_comb_final.show(10)

    //Output combined dataset with CheX_Image_ID as Master dataset
    df_comb_final.coalesce(1).write.format("com.databricks.spark.csv").option("header", "true").save(file_out_consolid)
  }

  //Function to generate sample datasets for subsequent processing
  def Generate_Sample {
    val df_comb: DataFrame = spark.read.format("CSV").option("header", "true").option("InferSchema", "true").load ("data/output/chexpert/Team68_CheXpert_Full")
    //hdfs:///9000/
    df_comb.show(10)
    println(df_comb.count)
    df_comb.createOrReplaceTempView("tbl_comb")

    //Select unique patient_id and Study (Patient Study) from the CheXpert training population
    val df_train_ps = sqlContext.sql("SELECT distinct patient_id, study from tbl_comb where dataset_id = 1")
    //val df_valid_ps = sqlContext.sql("SELECT distinct patient_id, study from tbl_comb where dataset_id = 2")

    //Add a unique sequence for each Patent Study
    val rdd_train_ps = df_train_ps.rdd.zipWithIndex()
    val df_sam_pop = rdd_train_ps.map(row => (row._2 + 1, row._1.getInt(0), row._1.getInt(1), 0, 1)).toDF("Seq_ID", "patient_id", "study", "selected", "select_01")

    //Calculate training and test size and generate random number lists for both populations
    val pop_count = df_train_ps.count.toInt
    val train_size = (num_sample * (1-size_test)).toInt
    val test_size = (num_sample * size_test).toInt
    scala.util.Random.setSeed(seed_value)
    var seq_try = 0

    //Generate "acceptable" training and test datasets unless max tries are exceeded
    breakable
    {
      while (seq_try < max_try) {
        //var rand_train = List.fill(train_size)(pop_count - 1).map(scala.util.Random.nextInt)
        //var rand_test = List.fill(test_size)(pop_count - train_size - 1).map(scala.util.Random.nextInt)
        //rand_train = rand_train.map(x => x + 1)
        //rand_test = rand_test.map(x => x + 1)
        seq_try += 1
        var rand_train = scala.util.Random.shuffle(1 to pop_count).take(train_size)
        var rand_test = scala.util.Random.shuffle(1 to pop_count-train_size).take(test_size)

        //Update "selected" column for sampled Patient_Study training data
        var df_sam_train = df_sam_pop.filter($"Seq_ID" isin (rand_train: _*)).withColumn("selected", $"select_01")
        //df_sam_train.show(20)
        //println("Alpha 01")
        //Exclude sampled training data from CheXpert population and re-sequence patient study (for test population)
        var df_train_ps2 = df_sam_pop.filter(!$"Seq_ID".isin(rand_train: _*))
        var rdd_train_ps2 = df_train_ps2.rdd.zipWithIndex()
        var df_sam_pop2 = rdd_train_ps2.map(row => (row._2 + 1, row._1.getInt(1), row._1.getInt(2), 0, 1)).toDF("Seq_ID", "patient_id", "study", "selected", "select_01")
        //df_sam_pop2.show(20)
        //println("Alpha 02")
        //Update "selected" column for sampled Patient_Study test data
        var df_sam_test = df_sam_pop2.filter($"Seq_ID" isin (rand_test: _*)).withColumn("selected", $"select_01")
        //df_sam_test.show(20)
        //println("Alpha 03")

        //Verify/Validate training and testing representiveness
        df_sam_train.createOrReplaceTempView("tbl_sample_train")
        df_sam_test.createOrReplaceTempView("tbl_sample_test")
        var df_sample_train = sqlContext.sql("SELECT a.* from tbl_comb as a inner join tbl_sample_train as b on a.patient_id = b.patient_id and a.study = b.study")
        var df_sample_test = sqlContext.sql("SELECT a.* from tbl_comb as a inner join tbl_sample_test as b on a.patient_id = b.patient_id and a.study = b.study")
        df_sample_train.show(20)

        val df_pass_train = Grade_Dataset(df_sample_train)
        val df_pass_test = Grade_Dataset(df_sample_test)
        if (df_pass_train == 1 & df_pass_test == 1) {
          //Consolidate training and test population and extract and export "essential" data
          var df_sample = sqlContext.sql("SELECT chex_image_id, 1 as Pop_ID, case when ap_pa_ll = 'AP' then 1 when ap_pa_ll = 'PA' then 2 else 3 end as Posit_ID from tbl_comb as a inner join tbl_sample_train as b on a.patient_id = b.patient_id and a.study = b.study UNION SELECT chex_image_id, 2 as Pop_ID, case when ap_pa_ll = 'AP' then 1 when ap_pa_ll = 'PA' then 2 else 3 end as Posit_ID from tbl_comb as a inner join tbl_sample_test as b on a.patient_id = b.patient_id and a.study = b.study order by 1, 2, 3")
          //df_sample.show(20)

          //Export the sampled data
          df_sample.coalesce(1).write.format("com.databricks.spark.csv").option("header", "true").save(file_out_sample)
          break
        }
      }
    }
  }

  //Function to verify/validate whether sampled datasets pass representation tests
  def Grade_Dataset(df: DataFrame): Int ={
    var ds_grade = 1
    val pop_sample = df.count

    //Construct queries and retrieve counts for projection count and positive diagnosis count
    df.createOrReplaceTempView("tbl_sample_x")
    val df_x_proj = sqlContext.sql("SELECT count(case when ap_pa_ll = 'AP' then chex_image_id end) as AP_Count, count(case when ap_pa_ll = 'PA' then chex_image_id end) as PA_Count, count(case when ap_pa_ll = 'LL' then chex_image_id end) as LL_Count from tbl_sample_x")
    val df_x_diag = sqlContext.sql("SELECT count(case when No_Finding = 1 then chex_image_id end) as No_Finding_Count, " +
      "count(case when Enlarged_Cardiomediastinum = 1 then chex_image_id end) as Enlarged_Cardiomediastinum_Count, count(case when Cardiomegaly = 1 then chex_image_id end) as Cardiomegaly_Count," +
      "count(case when Lung_Opacity = 1 then chex_image_id end) as Lung_Opacity_Count, count(case when Lung_Lesion = 1 then chex_image_id end) as Lung_Lesion_Count," +
      "count(case when Edema = 1 then chex_image_id end) as Edema_Count, count(case when Consolidation = 1 then chex_image_id end) as Consolidation_Count," +
      "count(case when Pneumonia = 1 then chex_image_id end) as Pneumonia_Count, count(case when Atelectasis = 1 then chex_image_id end) as Atelectasis_Count," +
      "count(case when Pneumothorax = 1 then chex_image_id end) as Pneumothorax_Count, count(case when Pleural_Effusion = 1 then chex_image_id end) as Pleural_Effusion_Count," +
      "count(case when Pleural_Other = 1 then chex_image_id end) as Pleural_Other_Count, count(case when Fracture = 1 then chex_image_id end) as Fracture_Count," +
      "count(case when Support_Devices = 1 then chex_image_id end) as Support_Devices_Count from tbl_sample_x")
    val x_proj = df_x_proj.rdd.map(row => (row(0), row(1), row(2))).collect().toList
    val x_diag = df_x_diag.rdd.map(row => (row(0), row(1), row(2), row(3), row(4), row(5), row(6), row(7), row(8), row(9), row(10), row(11), row(12), row(13))).collect().toList
    val x_proj2 = x_proj(0).asInstanceOf[(Long, Long, Long)]
    val x_diag2 = x_diag(0).asInstanceOf[(Long, Long, Long, Long, Long, Long, Long, Long, Long, Long, Long, Long, Long, Long)]

    //Compare actual vs minimum threshold for projection
    for (idx <- 0 to (min_proj_perc.length-1)) {
      var proj_perc_thr = min_proj_perc(idx).toDouble
      var proj_perc_act = 1.0
      if (idx == 0){proj_perc_act = x_proj2._1.toDouble/pop_sample.toDouble}
      if (idx == 1){proj_perc_act = x_proj2._2.toDouble/pop_sample.toDouble}
      if (idx == 2){proj_perc_act = x_proj2._3.toDouble/pop_sample.toDouble}
      //println(proj_perc_thr)
      //println(proj_perc_act)
      if (proj_perc_thr > proj_perc_act){ds_grade = 0}
    }

    //Compare actual vs minimum threshold for diagnosis
    for (idx <- 0 to (min_diag_perc.length-1)) {
      var diag_count_thr = min_diag_perc(idx).toDouble * pop_sample.toDouble
      var diag_count_act = 1.0
      if (idx == 0){diag_count_act = x_diag2._1}
      if (idx == 1){diag_count_act = x_diag2._2}
      if (idx == 2){diag_count_act = x_diag2._3}
      if (idx == 3){diag_count_act = x_diag2._4}
      if (idx == 4){diag_count_act = x_diag2._5}
      if (idx == 5){diag_count_act = x_diag2._6}
      if (idx == 6){diag_count_act = x_diag2._7}
      if (idx == 7){diag_count_act = x_diag2._8}
      if (idx == 8){diag_count_act = x_diag2._9}
      if (idx == 9){diag_count_act = x_diag2._10}
      if (idx == 10){diag_count_act = x_diag2._11}
      if (idx == 11){diag_count_act = x_diag2._12}
      if (idx == 12){diag_count_act = x_diag2._13}
      if (idx == 13){diag_count_act = x_diag2._14}
      //println(diag_count_thr)
      //println(diag_count_act)
      if (diag_count_thr > diag_count_act){ds_grade = 0}
    }

    return ds_grade
  }

  spark.stop()
  //val ages = Seq(64, 32, 23, 11)
  //println(s"Oldest person is ${ages.max}")
}
